# ScanTrad Clean 1.0.2

Rebuild propre de ScanTrad. Aucun code de la série 0.x n'est réutilisé.

## Comportement AUTO

- Pas de boucle de disparition/réapparition provoquée par les propres bulles de ScanTrad.
- L'apparition de l'overlay est explicitement ignorée par le détecteur de mouvement.
- En cas de vrai scroll/changement de page, l'ancienne traduction est retirée une seule fois car elle n'est plus alignée avec le contenu.
- Plus d'attente longue de ~420 ms : seulement un debounce technique d'environ 100 ms pour ne pas lancer l'OCR sur une frame encore en mouvement.
- Dès qu'une nouvelle traduction est prête, elle est affichée et reste stable.

## Moteurs

- Capture Android via MediaProjection dans un foreground service conforme Android récent.
- OCR Latin/Japonais/Chinois/Coréen, modèles OCR inclus dans l'APK.
- Identification automatique de la langue.
- Traduction vers le français avec ML Kit.
- Cache des traductions et modèles par langue.
- Overlay StaticLayout avec espaces, retours à la ligne et taille adaptative.
- Contrôle flottant AUTO / PAUSE / X.

## Important

La qualité linguistique de ML Kit reste celle d'un moteur local léger. `TranslationEngine` reste isolé pour pouvoir ajouter ensuite un mode Qualité sans réécrire la capture, l'OCR ou l'overlay.

## Historique

### 1.0.2
- Corrige la disparition quasi instantanée des bulles causée par l'overlay lui-même.
- Réduit la stabilisation de 420 ms à ~100 ms.
- Supprime le libellé et le comportement « traduction après le scroll » au profit d'un AUTO plus réactif.

### 1.0.1
- Correction compilation Kotlin dans `OcrEngine.quality`: `String.length` à la place de `String.size`.
