package com.scantrad.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class TranslationOverlay {

    public interface ControlsListener {
        void onPauseToggle();
        void onStop();
    }

    private final Context context;
    private final WindowManager windowManager;
    private final FrameLayout contentRoot;
    private final LinearLayout controls;
    private final TextView modeText;
    private final int screenWidth;
    private final int screenHeight;
    private boolean added;
    private String lastFingerprint = "";

    public TranslationOverlay(Context context, int screenWidth, int screenHeight, ControlsListener listener) {
        this.context = context;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        contentRoot = new FrameLayout(context);
        contentRoot.setClipChildren(false);
        contentRoot.setClipToPadding(false);

        controls = new LinearLayout(context);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(dp(10), dp(6), dp(6), dp(6));
        controls.setBackground(roundRect(Color.argb(225, 24, 26, 31), dp(18)));

        modeText = controlText("AUTO");
        TextView pause = controlText("⏸");
        TextView close = controlText("✕");

        pause.setPadding(dp(12), dp(7), dp(12), dp(7));
        close.setPadding(dp(12), dp(7), dp(12), dp(7));

        controls.addView(modeText);
        controls.addView(pause);
        controls.addView(close);

        pause.setOnClickListener(v -> listener.onPauseToggle());
        close.setOnClickListener(v -> listener.onStop());
    }

    public void show() {
        if (added) return;

        // FLAG_SECURE keeps ScanTrad's own overlay out of MediaProjection captures.
        // That lets the overlay stay visible while OCR runs, eliminating the old blink.
        WindowManager.LayoutParams contentParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
                        WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT
        );
        contentParams.gravity = Gravity.TOP | Gravity.START;

        WindowManager.LayoutParams controlParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT
        );
        controlParams.gravity = Gravity.TOP | Gravity.END;
        controlParams.x = dp(12);
        controlParams.y = dp(72);

        windowManager.addView(contentRoot, contentParams);
        windowManager.addView(controls, controlParams);
        added = true;
    }

    public void setMode(String text) {
        modeText.setText(text);
    }

    public void clearTranslations() {
        lastFingerprint = "";
        contentRoot.removeAllViews();
    }

    public void render(List<TranslationBox> boxes, int bitmapWidth, int bitmapHeight) {
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return;

        String fingerprint = fingerprint(boxes);
        if (fingerprint.equals(lastFingerprint)) return;
        lastFingerprint = fingerprint;

        float sx = screenWidth / (float) bitmapWidth;
        float sy = screenHeight / (float) bitmapHeight;

        // Build all views first. Android will draw the new frame after this method returns,
        // so remove+add happens as one visual update instead of a visible blank interval.
        contentRoot.removeAllViews();

        for (TranslationBox box : boxes) {
            Rect r = box.bounds;
            if (r == null || box.translated == null || box.translated.trim().isEmpty()) continue;

            int rawLeft = Math.round(r.left * sx);
            int rawTop = Math.round(r.top * sy);
            int rawWidth = Math.max(dp(34), Math.round(r.width() * sx));
            int rawHeight = Math.max(dp(28), Math.round(r.height() * sy));

            String text = box.translated.trim();
            BoxLayout layout = calculateLayout(text, rawLeft, rawTop, rawWidth, rawHeight);

            TextView tv = new TextView(context);
            tv.setText(text);
            tv.setTextColor(Color.rgb(17, 17, 19));
            tv.setGravity(Gravity.CENTER);
            tv.setIncludeFontPadding(false);
            tv.setPadding(layout.padding, layout.padding / 2, layout.padding, layout.padding / 2);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, layout.textSizeSp);
            tv.setLineSpacing(dp(1), 1.06f);
            tv.setHorizontallyScrolling(false);
            tv.setSingleLine(false);
            tv.setBackground(roundRect(Color.argb(247, 255, 255, 255), dp(9)));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                tv.setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY);
                tv.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);
            }

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(layout.width, layout.height);
            lp.leftMargin = layout.left;
            lp.topMargin = layout.top;
            contentRoot.addView(tv, lp);
        }
    }

    private BoxLayout calculateLayout(String text, int rawLeft, int rawTop, int rawWidth, int rawHeight) {
        int padding = dp(7);
        int centerX = rawLeft + rawWidth / 2;
        int centerY = rawTop + rawHeight / 2;

        int minReadableWidth = text.length() > 20 ? dp(120) : dp(72);
        int width = Math.max(rawWidth + padding * 2, minReadableWidth);

        // Long French translations need more horizontal room than the original text,
        // especially for narrow Japanese vertical bubbles.
        if (rawHeight > rawWidth * 1.30f) {
            width = Math.max(width, Math.min((int) (screenWidth * 0.48f), Math.max(dp(150), rawHeight)));
        } else if (text.length() > 55) {
            width = Math.max(width, Math.min((int) (screenWidth * 0.62f), dp(230)));
        } else if (text.length() > 32) {
            width = Math.max(width, Math.min((int) (screenWidth * 0.55f), dp(180)));
        }
        width = Math.min(width, (int) (screenWidth * 0.68f));

        int availableTextWidth = Math.max(dp(40), width - padding * 2);
        float chosenSp = 16f;
        int textHeight = measureTextHeight(text, availableTextWidth, chosenSp);
        int maxHeight = Math.min((int) (screenHeight * 0.38f), Math.max(rawHeight + padding * 2, dp(230)));

        while (textHeight + padding * 2 > maxHeight && chosenSp > 10f) {
            chosenSp -= 1f;
            textHeight = measureTextHeight(text, availableTextWidth, chosenSp);
        }

        // Grow the rectangle instead of clipping the end of a translation.
        int height = Math.max(rawHeight + padding * 2, textHeight + padding * 2);
        height = Math.min(height, maxHeight);

        int left = centerX - width / 2;
        int top = centerY - height / 2;
        left = clamp(left, 0, Math.max(0, screenWidth - width));
        top = clamp(top, 0, Math.max(0, screenHeight - height));

        return new BoxLayout(left, top, width, height, padding, chosenSp);
    }

    private int measureTextHeight(String text, int width, float textSizeSp) {
        TextPaint paint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        paint.setTextSize(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP,
                textSizeSp,
                context.getResources().getDisplayMetrics()
        ));

        StaticLayout layout;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            layout = StaticLayout.Builder.obtain(text, 0, text.length(), paint, width)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setIncludePad(false)
                    .setLineSpacing(dp(1), 1.06f)
                    .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                    .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                    .build();
        } else {
            //noinspection deprecation
            layout = new StaticLayout(text, paint, width, Layout.Alignment.ALIGN_CENTER, 1.06f, dp(1), false);
        }
        return layout.getHeight();
    }

    private String fingerprint(List<TranslationBox> boxes) {
        StringBuilder sb = new StringBuilder();
        for (TranslationBox box : boxes) {
            if (box == null || box.bounds == null || box.translated == null) continue;
            Rect r = box.bounds;
            // Quantize positions slightly so tiny OCR jitter does not redraw every cycle.
            sb.append(r.left / 6).append(',')
                    .append(r.top / 6).append(',')
                    .append(r.right / 6).append(',')
                    .append(r.bottom / 6).append(':')
                    .append(box.translated.trim()).append('|');
        }
        return sb.toString();
    }

    public void remove() {
        if (!added) return;
        try { windowManager.removeView(contentRoot); } catch (Exception ignored) {}
        try { windowManager.removeView(controls); } catch (Exception ignored) {}
        added = false;
    }

    private TextView controlText(String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(8), dp(7), dp(8), dp(7));
        return view;
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static class BoxLayout {
        final int left;
        final int top;
        final int width;
        final int height;
        final int padding;
        final float textSizeSp;

        BoxLayout(int left, int top, int width, int height, int padding, float textSizeSp) {
            this.left = left;
            this.top = top;
            this.width = width;
            this.height = height;
            this.padding = padding;
            this.textSizeSp = textSizeSp;
        }
    }
}
