package com.scantrad.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 1001;
    private static final int REQ_NOTIFICATIONS = 1002;

    private TextView statusText;
    private Button overlayButton;
    private MediaProjectionManager projectionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        overlayButton = findViewById(R.id.overlayButton);
        Button startButton = findViewById(R.id.startButton);

        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        overlayButton.setOnClickListener(v -> requestOverlayPermission());
        startButton.setOnClickListener(v -> startAutoTranslation());

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionState();
    }

    private void refreshPermissionState() {
        boolean overlayAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        if (overlayAllowed) {
            statusText.setText("✓ Superposition autorisée\nPrêt à lancer la traduction.");
            overlayButton.setText("Superposition autorisée ✓");
        } else {
            statusText.setText("Superposition non autorisée. Active-la pour que les traductions puissent apparaître au-dessus de ton lecteur de scans.");
            overlayButton.setText("Autoriser la superposition");
        }
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
        } else {
            Toast.makeText(this, "La superposition est déjà autorisée.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startAutoTranslation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Autorise d'abord la superposition.", Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }

        Intent captureIntent = projectionManager.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != REQ_CAPTURE) return;

        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Capture d'écran refusée.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent serviceIntent = new Intent(this, ScreenTranslationService.class);
        serviceIntent.putExtra(ScreenTranslationService.EXTRA_RESULT_CODE, resultCode);
        serviceIntent.putExtra(ScreenTranslationService.EXTRA_RESULT_DATA, data);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        Toast.makeText(this, "ScanTrad AUTO lancé.", Toast.LENGTH_SHORT).show();
        moveTaskToBack(true);
    }
}
