package com.scantrad.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.WindowManager;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ScreenTranslationService extends Service {

    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";

    private static final String TAG = "ScanTrad";
    private static final String CHANNEL_ID = "scantrad_capture";
    private static final int NOTIFICATION_ID = 42;
    private static final long AUTO_INTERVAL_MS = 1100L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private HandlerThread captureThread;
    private Handler captureHandler;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private TextRecognizer latinRecognizer;
    private TextRecognizer japaneseRecognizer;
    private LanguageIdentifier languageIdentifier;
    private TranslationOverlay overlay;

    private int screenWidth;
    private int screenHeight;
    private int densityDpi;

    private volatile boolean paused = false;
    private volatile boolean captureRequested = false;
    private volatile boolean processing = false;
    private int consecutiveEmptyFrames = 0;

    private final Map<String, Translator> translators = new HashMap<>();
    private final Set<String> readyModels = new HashSet<>();
    private final Set<String> downloadingModels = new HashSet<>();
    private final Map<String, String> translationCache = new ConcurrentHashMap<>();

    private final Runnable autoLoop = new Runnable() {
        @Override
        public void run() {
            if (!paused && !processing) requestFreshFrame();
            mainHandler.postDelayed(this, AUTO_INTERVAL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Initialisation…"));

        captureThread = new HandlerThread("ScanTradCapture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        japaneseRecognizer = TextRecognition.getClient(
                new JapaneseTextRecognizerOptions.Builder().build()
        );
        languageIdentifier = LanguageIdentification.getClient(
                new LanguageIdentificationOptions.Builder()
                        .setConfidenceThreshold(0.34f)
                        .build()
        );

        resolveScreenSize();
        overlay = new TranslationOverlay(this, screenWidth, screenHeight,
                new TranslationOverlay.ControlsListener() {
                    @Override
                    public void onPauseToggle() {
                        paused = !paused;
                        overlay.setMode(paused ? "PAUSE" : "AUTO");
                        if (paused) {
                            overlay.clearTranslations();
                        } else {
                            requestFreshFrame();
                        }
                    }

                    @Override
                    public void onStop() {
                        stopSelf();
                    }
                });
        overlay.show();
        overlay.setMode("AUTO");
        updateNotification("Détection auto → français active");
        mainHandler.post(autoLoop);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            //noinspection deprecation
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }

        if (resultCode == 0 || resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (mediaProjection == null) {
            startProjection(resultCode, resultData);
        }

        return START_NOT_STICKY;
    }

    private void startProjection(int resultCode, Intent resultData) {
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = manager.getMediaProjection(resultCode, resultData);

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> stopSelf());
            }
        }, mainHandler);

        imageReader = ImageReader.newInstance(
                screenWidth,
                screenHeight,
                PixelFormat.RGBA_8888,
                2
        );
        imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScanTradScreen",
                screenWidth,
                screenHeight,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                captureHandler
        );

        requestFreshFrame();
    }

    private void requestFreshFrame() {
        if (captureRequested || processing || paused || imageReader == null) return;
        // The overlay windows are FLAG_SECURE, so MediaProjection does not capture them.
        // We can therefore keep translations visible continuously instead of hiding them.
        captureRequested = true;
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null || !captureRequested || processing || paused) return;

            captureRequested = false;
            processing = true;

            Bitmap bitmap = imageToBitmap(image);

            if (bitmap == null) {
                processing = false;
                return;
            }

            processBitmap(bitmap);
        } catch (Exception e) {
            Log.e(TAG, "Erreur de capture", e);
            captureRequested = false;
            processing = false;
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;

        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * screenWidth;
        int bitmapWidth = screenWidth + rowPadding / pixelStride;

        Bitmap padded = Bitmap.createBitmap(bitmapWidth, screenHeight, Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, screenWidth, screenHeight);
        if (padded != cropped) padded.recycle();
        return cropped;
    }

    private void processBitmap(Bitmap bitmap) {
        InputImage inputImage = InputImage.fromBitmap(bitmap, 0);

        Task<Text> latinTask = latinRecognizer.process(inputImage);
        Task<Text> japaneseTask = japaneseRecognizer.process(inputImage);

        Tasks.whenAllComplete(Arrays.asList(latinTask, japaneseTask))
                .addOnCompleteListener(ignored -> {
                    try {
                        List<OcrBlock> blocks = new ArrayList<>();
                        if (latinTask.isSuccessful() && latinTask.getResult() != null) {
                            collectBlocks(latinTask.getResult(), "latin", blocks);
                        }
                        if (japaneseTask.isSuccessful() && japaneseTask.getResult() != null) {
                            collectBlocks(japaneseTask.getResult(), "ja", blocks);
                        }

                        blocks = mergeNearbyBlocks(blocks);
                        translateDetectedBlocks(blocks, bitmap.getWidth(), bitmap.getHeight());
                    } catch (Exception e) {
                        Log.e(TAG, "Erreur après OCR", e);
                        processing = false;
                    } finally {
                        bitmap.recycle();
                    }
                });
    }

    private void collectBlocks(Text recognized, String hint, List<OcrBlock> merged) {
        for (Text.TextBlock block : recognized.getTextBlocks()) {
            String source = normalizePreservingWords(block.getText());
            Rect bounds = block.getBoundingBox();
            if (bounds == null || source.isEmpty()) continue;
            if (bounds.width() < 5 || bounds.height() < 5) continue;
            if (!containsLetterOrCjk(source)) continue;

            String recognizedLanguage = block.getRecognizedLanguage();
            if (recognizedLanguage == null || recognizedLanguage.trim().isEmpty()) {
                recognizedLanguage = "und";
            }
            addOrReplaceOverlapping(merged, new OcrBlock(
                    new Rect(bounds), source, hint, recognizedLanguage
            ));
        }
    }

    private void addOrReplaceOverlapping(List<OcrBlock> blocks, OcrBlock candidate) {
        for (int i = 0; i < blocks.size(); i++) {
            OcrBlock existing = blocks.get(i);
            if (intersectionOverUnion(existing.bounds, candidate.bounds) < 0.58f) continue;

            if (candidateScore(candidate) > candidateScore(existing)) {
                blocks.set(i, candidate);
            }
            return;
        }
        blocks.add(candidate);
    }

    private int candidateScore(OcrBlock block) {
        int score = Math.min(block.source.length(), 80);
        if (containsKana(block.source) && "ja".equals(block.hint)) score += 150;
        if (looksMostlyLatin(block.source) && "latin".equals(block.hint)) score += 90;
        if (containsHan(block.source) && "ja".equals(block.hint)) score += 25;
        return score;
    }

    private float intersectionOverUnion(Rect a, Rect b) {
        int left = Math.max(a.left, b.left);
        int top = Math.max(a.top, b.top);
        int right = Math.min(a.right, b.right);
        int bottom = Math.min(a.bottom, b.bottom);
        if (right <= left || bottom <= top) return 0f;

        long intersection = (long) (right - left) * (bottom - top);
        long union = (long) a.width() * a.height() + (long) b.width() * b.height() - intersection;
        return union <= 0 ? 0f : intersection / (float) union;
    }

    private void translateDetectedBlocks(List<OcrBlock> blocks, int bitmapWidth, int bitmapHeight) {
        if (blocks.isEmpty()) {
            consecutiveEmptyFrames++;
            if (consecutiveEmptyFrames >= 3) {
                mainHandler.post(() -> overlay.clearTranslations());
            }
            processing = false;
            return;
        }
        consecutiveEmptyFrames = 0;

        StringBuilder combinedBuilder = new StringBuilder();
        for (OcrBlock block : blocks) {
            if (combinedBuilder.length() > 0) combinedBuilder.append(' ');
            combinedBuilder.append(block.source);
        }

        Task<String> frameLanguageTask = languageIdentifier.identifyLanguage(combinedBuilder.toString());
        List<Task<String>> blockLanguageTasks = new ArrayList<>();

        for (OcrBlock block : blocks) {
            String scriptLanguage = obviousScriptLanguage(block.source);
            if (scriptLanguage != null) {
                blockLanguageTasks.add(Tasks.forResult(scriptLanguage));
            } else if (isUsefulLanguageHint(block.languageHint)) {
                blockLanguageTasks.add(Tasks.forResult(block.languageHint));
            } else {
                blockLanguageTasks.add(languageIdentifier.identifyLanguage(block.source));
            }
        }

        List<Task<?>> allLanguageTasks = new ArrayList<>();
        allLanguageTasks.add(frameLanguageTask);
        allLanguageTasks.addAll(blockLanguageTasks);

        Tasks.whenAllComplete(allLanguageTasks)
                .addOnCompleteListener(ignored -> {
                    String frameLanguage = successfulLanguage(frameLanguageTask);
                    if (frameLanguage == null) frameLanguage = "und";

                    List<Task<String>> translationTasks = new ArrayList<>();
                    List<OcrBlock> translatedBlocks = new ArrayList<>();
                    List<String> cacheKeys = new ArrayList<>();

                    for (int i = 0; i < blocks.size(); i++) {
                        OcrBlock block = blocks.get(i);
                        String languageTag = successfulLanguage(blockLanguageTasks.get(i));
                        if (languageTag == null || "und".equals(languageTag)) {
                            languageTag = frameLanguage;
                        }

                        String sourceLanguage = toTranslateLanguage(languageTag);
                        if (sourceLanguage == null || TranslateLanguage.FRENCH.equals(sourceLanguage)) continue;

                        String cacheKey = sourceLanguage + "|" + block.source;
                        String cached = translationCache.get(cacheKey);
                        if (cached != null) {
                            translationTasks.add(Tasks.forResult(cached));
                            translatedBlocks.add(block);
                            cacheKeys.add(cacheKey);
                            continue;
                        }

                        Translator translator = getReadyTranslator(sourceLanguage);
                        if (translator == null) continue;

                        translationTasks.add(translator.translate(block.source));
                        translatedBlocks.add(block);
                        cacheKeys.add(cacheKey);
                    }

                    if (translationTasks.isEmpty()) {
                        // Keep the previous overlay while a language model is downloading or
                        // while short OCR fragments are temporarily uncertain.
                        processing = false;
                        return;
                    }

                    Tasks.whenAllComplete(translationTasks)
                            .addOnCompleteListener(done -> {
                                List<TranslationBox> boxes = new ArrayList<>();
                                for (int i = 0; i < translationTasks.size(); i++) {
                                    Task<String> task = translationTasks.get(i);
                                    if (!task.isSuccessful() || task.getResult() == null) continue;

                                    String translated = cleanupTranslatedText(task.getResult());
                                    if (translated.isEmpty()) continue;

                                    OcrBlock sourceBlock = translatedBlocks.get(i);
                                    translationCache.put(cacheKeys.get(i), translated);
                                    boxes.add(new TranslationBox(
                                            sourceBlock.bounds,
                                            sourceBlock.source,
                                            translated
                                    ));
                                }

                                mainHandler.post(() -> overlay.render(boxes, bitmapWidth, bitmapHeight));
                                processing = false;
                            });
                });
    }

    private String successfulLanguage(Task<String> task) {
        if (task == null || !task.isSuccessful() || task.getResult() == null) return null;
        return task.getResult();
    }

    private String toTranslateLanguage(String languageTag) {
        if (languageTag == null || languageTag.trim().isEmpty() || "und".equals(languageTag)) return null;

        String translated = TranslateLanguage.fromLanguageTag(languageTag);
        if (translated != null) return translated;

        int dash = languageTag.indexOf('-');
        if (dash > 0) {
            return TranslateLanguage.fromLanguageTag(languageTag.substring(0, dash));
        }
        return null;
    }

    private Translator getReadyTranslator(String sourceLanguage) {
        synchronized (translators) {
            Translator translator = translators.get(sourceLanguage);
            if (translator == null) {
                TranslatorOptions options = new TranslatorOptions.Builder()
                        .setSourceLanguage(sourceLanguage)
                        .setTargetLanguage(TranslateLanguage.FRENCH)
                        .build();
                translator = Translation.getClient(options);
                translators.put(sourceLanguage, translator);
            }

            if (readyModels.contains(sourceLanguage)) return translator;

            if (!downloadingModels.contains(sourceLanguage)) {
                downloadingModels.add(sourceLanguage);
                String code = sourceLanguage.toUpperCase(Locale.ROOT);
                mainHandler.post(() -> overlay.setMode("DL " + code));
                updateNotification("Téléchargement du modèle " + code + " → FR");

                DownloadConditions conditions = new DownloadConditions.Builder().build();
                Translator finalTranslator = translator;
                finalTranslator.downloadModelIfNeeded(conditions)
                        .addOnSuccessListener(v -> {
                            synchronized (translators) {
                                downloadingModels.remove(sourceLanguage);
                                readyModels.add(sourceLanguage);
                            }
                            mainHandler.post(() -> {
                                overlay.setMode(paused ? "PAUSE" : "AUTO");
                                if (!paused) requestFreshFrame();
                            });
                            updateNotification("Détection auto → français active");
                        })
                        .addOnFailureListener(e -> {
                            Log.e(TAG, "Impossible de télécharger le modèle " + sourceLanguage, e);
                            synchronized (translators) {
                                downloadingModels.remove(sourceLanguage);
                            }
                            mainHandler.post(() -> overlay.setMode("DL ERR"));
                            updateNotification("Erreur de téléchargement du modèle " + code);
                        });
            }

            return null;
        }
    }

    private String obviousScriptLanguage(String text) {
        if (containsKana(text)) return "ja";
        if (containsHangul(text)) return "ko";
        return null;
    }

    private boolean containsKana(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '\u3040' && c <= '\u30FF') || (c >= '\u31F0' && c <= '\u31FF')) {
                return true;
            }
        }
        return false;
    }

    private boolean containsHangul(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '\uAC00' && c <= '\uD7AF') || (c >= '\u1100' && c <= '\u11FF')) {
                return true;
            }
        }
        return false;
    }

    private boolean containsHan(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '\u3400' && c <= '\u4DBF') || (c >= '\u4E00' && c <= '\u9FFF')) {
                return true;
            }
        }
        return false;
    }

    private boolean looksMostlyLatin(String text) {
        int letters = 0;
        int latin = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (!Character.isLetter(c)) continue;
            letters++;
            Character.UnicodeBlock block = Character.UnicodeBlock.of(c);
            if (block == Character.UnicodeBlock.BASIC_LATIN ||
                    block == Character.UnicodeBlock.LATIN_1_SUPPLEMENT ||
                    block == Character.UnicodeBlock.LATIN_EXTENDED_A ||
                    block == Character.UnicodeBlock.LATIN_EXTENDED_B) {
                latin++;
            }
        }
        return letters > 0 && latin >= Math.max(1, (int) Math.ceil(letters * 0.7));
    }

    private boolean containsLetterOrCjk(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetter(c) ||
                    (c >= '\u3040' && c <= '\u30FF') ||
                    (c >= '\u3400' && c <= '\u9FFF')) {
                return true;
            }
        }
        return false;
    }

    private String normalizePreservingWords(String text) {
        if (text == null) return "";
        // ML Kit separates TextBlock lines with \n. Convert those boundaries to spaces
        // instead of concatenating them, which is especially important for Latin scans.
        return text.replace('\n', ' ').replaceAll("\\s+", " ").trim();
    }

    private String cleanupTranslatedText(String text) {
        if (text == null) return "";
        String cleaned = text.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        // Repair a few common OCR/translation punctuation joins without touching apostrophes.
        cleaned = cleaned.replaceAll("([,;:!?])(?=[\\p{L}\\p{N}])", "$1 ");
        cleaned = cleaned.replaceAll("\\.(?=[\\p{L}])", ". ");
        cleaned = cleaned.replaceAll("(?<=[\\p{Ll}\\p{Nd}])(?=[\\p{Lu}])", " ");
        return cleaned.replaceAll("\\s+", " ").trim();
    }

    private boolean isUsefulLanguageHint(String languageTag) {
        return languageTag != null && !languageTag.trim().isEmpty() && !"und".equals(languageTag);
    }

    private List<OcrBlock> mergeNearbyBlocks(List<OcrBlock> input) {
        if (input.size() < 2) return input;

        boolean[] used = new boolean[input.size()];
        List<OcrBlock> output = new ArrayList<>();

        for (int i = 0; i < input.size(); i++) {
            if (used[i]) continue;

            List<OcrBlock> group = new ArrayList<>();
            List<Integer> queue = new ArrayList<>();
            queue.add(i);
            used[i] = true;

            for (int q = 0; q < queue.size(); q++) {
                int index = queue.get(q);
                OcrBlock current = input.get(index);
                group.add(current);

                for (int j = 0; j < input.size(); j++) {
                    if (used[j]) continue;
                    if (shouldMerge(current, input.get(j))) {
                        used[j] = true;
                        queue.add(j);
                    }
                }
            }

            if (group.size() == 1) {
                output.add(group.get(0));
            } else {
                output.add(mergeGroup(group));
            }
        }
        return output;
    }

    private boolean shouldMerge(OcrBlock a, OcrBlock b) {
        if (!a.hint.equals(b.hint)) return false;

        Rect ra = a.bounds;
        Rect rb = b.bounds;
        int overlapX = Math.max(0, Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left));
        int overlapY = Math.max(0, Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top));
        float overlapXRatio = overlapX / (float) Math.max(1, Math.min(ra.width(), rb.width()));
        float overlapYRatio = overlapY / (float) Math.max(1, Math.min(ra.height(), rb.height()));

        int horizontalGap = Math.max(0, Math.max(ra.left, rb.left) - Math.min(ra.right, rb.right));
        int verticalGap = Math.max(0, Math.max(ra.top, rb.top) - Math.min(ra.bottom, rb.bottom));

        int verticalLimit = Math.max(28, Math.min(ra.height(), rb.height()));
        int horizontalLimit = Math.max(28, Math.min(ra.width(), rb.width()));

        // Lines stacked in one speech bubble.
        if (overlapXRatio >= 0.25f && verticalGap <= verticalLimit) return true;
        // Japanese vertical columns or split Latin fragments inside one bubble.
        if (overlapYRatio >= 0.30f && horizontalGap <= horizontalLimit) return true;

        return false;
    }

    private OcrBlock mergeGroup(List<OcrBlock> group) {
        Rect union = new Rect(group.get(0).bounds);
        boolean japanese = false;
        String languageHint = "und";

        for (OcrBlock block : group) {
            union.union(block.bounds);
            if ("ja".equals(block.hint) || containsKana(block.source)) japanese = true;
            if (isUsefulLanguageHint(block.languageHint)) {
                if ("und".equals(languageHint)) languageHint = block.languageHint;
                else if (!languageHint.equals(block.languageHint)) languageHint = "und";
            }
        }

        final boolean japaneseGroup = japanese;
        group.sort((a, b) -> {
            if (japaneseGroup) {
                int byRight = Integer.compare(b.bounds.right, a.bounds.right);
                if (Math.abs(b.bounds.right - a.bounds.right) > 20) return byRight;
                return Integer.compare(a.bounds.top, b.bounds.top);
            }
            int byTop = Integer.compare(a.bounds.top, b.bounds.top);
            if (Math.abs(a.bounds.top - b.bounds.top) > 20) return byTop;
            return Integer.compare(a.bounds.left, b.bounds.left);
        });

        StringBuilder joined = new StringBuilder();
        for (OcrBlock block : group) {
            if (joined.length() > 0) joined.append(' ');
            joined.append(block.source);
        }

        return new OcrBlock(union, normalizePreservingWords(joined.toString()),
                japaneseGroup ? "ja" : group.get(0).hint, languageHint);
    }

    private void resolveScreenSize() {
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        densityDpi = getResources().getDisplayMetrics().densityDpi;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Rect bounds = wm.getMaximumWindowMetrics().getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
        } else {
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
            //noinspection deprecation
            wm.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            densityDpi = metrics.densityDpi;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "ScanTrad",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Capture d'écran utilisée pour la traduction des scans");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setContentTitle("ScanTrad")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);

        if (overlay != null) overlay.remove();
        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            imageReader.close();
        }
        if (virtualDisplay != null) virtualDisplay.release();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) {}
        }
        if (latinRecognizer != null) latinRecognizer.close();
        if (japaneseRecognizer != null) japaneseRecognizer.close();
        if (languageIdentifier != null) languageIdentifier.close();
        synchronized (translators) {
            for (Translator translator : translators.values()) {
                try { translator.close(); } catch (Exception ignored) {}
            }
            translators.clear();
        }
        if (captureThread != null) captureThread.quitSafely();

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static class OcrBlock {
        final Rect bounds;
        final String source;
        final String hint;
        final String languageHint;

        OcrBlock(Rect bounds, String source, String hint, String languageHint) {
            this.bounds = bounds;
            this.source = source;
            this.hint = hint;
            this.languageHint = languageHint;
        }
    }
}
