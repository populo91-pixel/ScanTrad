package com.scantrad.app;

import android.graphics.Rect;

public class TranslationBox {
    public final Rect bounds;
    public final String source;
    public final String translated;

    public TranslationBox(Rect bounds, String source, String translated) {
        this.bounds = bounds;
        this.source = source;
        this.translated = translated;
    }
}
