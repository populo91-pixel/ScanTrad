# ScanTrad 0.3

Prototype Android personnel de traduction de scans affichés à l'écran.

## 0.3 — qualité/stabilité
- overlay marqué `FLAG_SECURE` : il reste visible pendant la capture et ne clignote plus
- les traductions déjà affichées restent en place pendant l'OCR suivant
- regroupement de blocs OCR proches pour traduire des phrases plus complètes
- utilisation de l'indice de langue fourni par l'OCR quand il existe
- nettoyage des espaces/ponctuation dans le texte traduit
- zones françaises qui s'agrandissent automatiquement pour éviter de couper la fin des phrases
- anti-redessin sur les petites variations OCR afin de stabiliser l'affichage

## Langues
- OCR japonais + alphabet latin
- détection automatique de la langue
- traduction locale vers le français via ML Kit

## Limites connues
- ce prototype ne détecte pas encore la forme exacte des bulles
- les blocs blancs peuvent recouvrir un peu le dessin si la traduction française est beaucoup plus longue
- l'OCR peut encore rater du texte très stylisé, très petit, incliné ou intégré au dessin
