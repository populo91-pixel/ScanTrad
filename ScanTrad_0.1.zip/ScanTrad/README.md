# ScanTrad 0.1

Prototype Android personnel : traduction automatique japonais → français par-dessus un lecteur de scans.

## Ce que fait cette version

- capture l'écran avec l'autorisation Android `MediaProjection` ;
- détecte le japonais avec ML Kit Text Recognition v2 ;
- traduit japonais → français avec ML Kit on-device ;
- affiche la traduction au-dessus du scan ;
- actualise automatiquement environ toutes les 1,35 s pendant le scroll ;
- petit contrôle flottant `AUTO / pause / X` ;
- cache les traductions déjà vues pour accélérer les rafraîchissements.

## Limites du prototype

- les blocs français masquent le texte original avec un fond blanc ; il n'y a pas encore d'inpainting/reconstruction du dessin ;
- l'OCR peut rater du texte très stylisé, minuscule ou incliné ;
- les traductions de manga très familières peuvent manquer de contexte ;
- portrait recommandé ; si tu tournes le téléphone, relance la session ;
- au démarrage du partage d'écran, choisis **l'écran entier** pour que les coordonnées des bulles correspondent à l'overlay ;
- la première traduction télécharge le modèle japonais→français (environ quelques dizaines de Mo). Ensuite il fonctionne hors ligne.

## Installation pour quelqu'un qui ne code pas

1. Installe Android Studio sur ton PC.
2. Décompresse ce dossier.
3. Dans Android Studio : **Open** → sélectionne le dossier `ScanTrad`.
4. Laisse Android Studio télécharger/synchroniser les dépendances.
5. Branche ton téléphone Android en USB et active **Options développeur → Débogage USB**.
6. Dans Android Studio, sélectionne ton téléphone puis appuie sur ▶ **Run**.
7. Sur le téléphone :
   - autorise la superposition ;
   - ouvre ton scan dans le navigateur ;
   - reviens dans ScanTrad ;
   - appuie sur **Lancer la traduction AUTO** ;
   - dans la fenêtre Android, choisis **écran entier**.

## Suite logique (0.2)

- détection de la forme des bulles pour agrandir intelligemment la zone française ;
- détection du scroll au lieu d'un rafraîchissement fixe ;
- reconstruction/inpainting du texte dessiné directement sur l'image ;
- choix JP→FR / EN→FR ;
- mode « appui pour afficher l'original » ;
- réglage fréquence/qualité OCR ;
- traduction contextuelle de plusieurs bulles ensemble pour de meilleurs dialogues.

### Note Gradle

Le projet est destiné à être ouvert directement dans Android Studio. Le fichier `gradle-wrapper.properties` fixe Gradle 8.13 ; le binaire wrapper n'est pas inclus dans cette archive, Android Studio téléchargera les outils nécessaires lors de la synchronisation.
