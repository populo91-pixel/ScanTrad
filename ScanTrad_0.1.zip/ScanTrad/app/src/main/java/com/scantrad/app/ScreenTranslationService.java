package com.scantrad.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.WindowManager;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ScreenTranslationService extends Service {

    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";

    private static final String TAG = "ScanTrad";
    private static final String CHANNEL_ID = "scantrad_capture";
    private static final int NOTIFICATION_ID = 42;
    private static final long AUTO_INTERVAL_MS = 1350L;
    private static final long OVERLAY_HIDE_DELAY_MS = 90L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private HandlerThread captureThread;
    private Handler captureHandler;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private TextRecognizer recognizer;
    private Translator translator;
    private TranslationOverlay overlay;

    private int screenWidth;
    private int screenHeight;
    private int densityDpi;

    private volatile boolean paused = false;
    private volatile boolean captureRequested = false;
    private volatile boolean processing = false;
    private volatile boolean modelReady = false;

    private final Map<String, String> translationCache = new ConcurrentHashMap<>();

    private final Runnable autoLoop = new Runnable() {
        @Override
        public void run() {
            if (!paused && modelReady && !processing) requestFreshFrame();
            mainHandler.postDelayed(this, AUTO_INTERVAL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Initialisation…"));

        captureThread = new HandlerThread("ScanTradCapture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        recognizer = TextRecognition.getClient(
                new JapaneseTextRecognizerOptions.Builder().build()
        );

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.JAPANESE)
                .setTargetLanguage(TranslateLanguage.FRENCH)
                .build();
        translator = Translation.getClient(options);

        resolveScreenSize();
        overlay = new TranslationOverlay(this, screenWidth, screenHeight,
                new TranslationOverlay.ControlsListener() {
                    @Override
                    public void onPauseToggle() {
                        paused = !paused;
                        overlay.setMode(paused ? "PAUSE" : "AUTO");
                        if (paused) {
                            overlay.clearTranslations();
                        } else {
                            requestFreshFrame();
                        }
                    }

                    @Override
                    public void onStop() {
                        stopSelf();
                    }
                });
        overlay.show();
        overlay.setMode("MODÈLE…");

        DownloadConditions conditions = new DownloadConditions.Builder().build();
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(v -> {
                    modelReady = true;
                    overlay.setMode("AUTO");
                    updateNotification("Traduction automatique active");
                    mainHandler.removeCallbacks(autoLoop);
                    mainHandler.post(autoLoop);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Impossible de télécharger le modèle de traduction", e);
                    overlay.setMode("ERREUR");
                    updateNotification("Erreur de modèle de traduction");
                });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            //noinspection deprecation
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }

        if (resultCode == 0 || resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (mediaProjection == null) {
            startProjection(resultCode, resultData);
        }

        return START_NOT_STICKY;
    }

    private void startProjection(int resultCode, Intent resultData) {
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = manager.getMediaProjection(resultCode, resultData);

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> stopSelf());
            }
        }, mainHandler);

        imageReader = ImageReader.newInstance(
                screenWidth,
                screenHeight,
                PixelFormat.RGBA_8888,
                2
        );
        imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScanTradScreen",
                screenWidth,
                screenHeight,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                captureHandler
        );

        if (modelReady) requestFreshFrame();
    }

    private void requestFreshFrame() {
        if (captureRequested || processing || paused || imageReader == null) return;

        overlay.setContentVisible(false);
        mainHandler.postDelayed(() -> {
            captureRequested = true;
            // Si aucune frame n'arrive immédiatement, l'ancienne traduction revient quand même.
            mainHandler.postDelayed(() -> overlay.setContentVisible(true), 180L);
        }, OVERLAY_HIDE_DELAY_MS);
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null || !captureRequested || processing || paused) return;

            captureRequested = false;
            processing = true;

            Bitmap bitmap = imageToBitmap(image);
            mainHandler.post(() -> overlay.setContentVisible(true));

            if (bitmap == null) {
                processing = false;
                return;
            }

            processBitmap(bitmap);
        } catch (Exception e) {
            Log.e(TAG, "Erreur de capture", e);
            captureRequested = false;
            processing = false;
            mainHandler.post(() -> overlay.setContentVisible(true));
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;

        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * screenWidth;
        int bitmapWidth = screenWidth + rowPadding / pixelStride;

        Bitmap padded = Bitmap.createBitmap(bitmapWidth, screenHeight, Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, screenWidth, screenHeight);
        if (padded != cropped) padded.recycle();
        return cropped;
    }

    private void processBitmap(Bitmap bitmap) {
        InputImage inputImage = InputImage.fromBitmap(bitmap, 0);

        recognizer.process(inputImage)
                .addOnSuccessListener(text -> translateDetectedBlocks(text, bitmap.getWidth(), bitmap.getHeight()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Erreur OCR", e);
                    processing = false;
                })
                .addOnCompleteListener(task -> bitmap.recycle());
    }

    private void translateDetectedBlocks(Text recognized, int bitmapWidth, int bitmapHeight) {
        List<Text.TextBlock> japaneseBlocks = new ArrayList<>();
        for (Text.TextBlock block : recognized.getTextBlocks()) {
            String source = normalize(block.getText());
            Rect bounds = block.getBoundingBox();
            if (bounds == null || source.length() < 1 || !containsJapanese(source)) continue;
            if (bounds.width() < 5 || bounds.height() < 5) continue;
            japaneseBlocks.add(block);
        }

        if (japaneseBlocks.isEmpty()) {
            mainHandler.post(() -> overlay.clearTranslations());
            processing = false;
            return;
        }

        List<Task<String>> tasks = new ArrayList<>();
        List<Rect> bounds = new ArrayList<>();
        List<String> sources = new ArrayList<>();

        for (Text.TextBlock block : japaneseBlocks) {
            String source = normalize(block.getText());
            String cached = translationCache.get(source);
            Task<String> task = cached != null ? Tasks.forResult(cached) : translator.translate(source);
            tasks.add(task);
            bounds.add(new Rect(block.getBoundingBox()));
            sources.add(source);
        }

        Tasks.whenAllComplete(tasks)
                .addOnCompleteListener(ignored -> {
                    List<TranslationBox> boxes = new ArrayList<>();
                    for (int i = 0; i < tasks.size(); i++) {
                        Task<String> task = tasks.get(i);
                        if (!task.isSuccessful() || task.getResult() == null) continue;

                        String translated = task.getResult().trim();
                        if (translated.isEmpty()) continue;

                        translationCache.put(sources.get(i), translated);
                        boxes.add(new TranslationBox(bounds.get(i), sources.get(i), translated));
                    }

                    mainHandler.post(() -> overlay.render(boxes, bitmapWidth, bitmapHeight));
                    processing = false;
                });
    }

    private boolean containsJapanese(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= '\u3040' && c <= '\u30FF') ||      // Hiragana + Katakana
                    (c >= '\u3400' && c <= '\u4DBF') || // CJK Extension A
                    (c >= '\u4E00' && c <= '\u9FFF')) { // Kanji
                return true;
            }
        }
        return false;
    }

    private String normalize(String text) {
        if (text == null) return "";
        return text.replace('\n', ' ').replaceAll("\\s+", " ").trim();
    }

    private void resolveScreenSize() {
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        densityDpi = getResources().getDisplayMetrics().densityDpi;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Rect bounds = wm.getMaximumWindowMetrics().getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
        } else {
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
            //noinspection deprecation
            wm.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            densityDpi = metrics.densityDpi;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "ScanTrad",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Capture d'écran utilisée pour la traduction des scans");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setContentTitle("ScanTrad")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);

        if (overlay != null) overlay.remove();
        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            imageReader.close();
        }
        if (virtualDisplay != null) virtualDisplay.release();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) {}
        }
        if (recognizer != null) recognizer.close();
        if (translator != null) translator.close();
        if (captureThread != null) captureThread.quitSafely();

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
