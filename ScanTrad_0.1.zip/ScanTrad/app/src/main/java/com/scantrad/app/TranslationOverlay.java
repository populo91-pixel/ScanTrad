package com.scantrad.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class TranslationOverlay {

    public interface ControlsListener {
        void onPauseToggle();
        void onStop();
    }

    private final Context context;
    private final WindowManager windowManager;
    private final FrameLayout contentRoot;
    private final LinearLayout controls;
    private final TextView modeText;
    private final int screenWidth;
    private final int screenHeight;
    private boolean added;

    public TranslationOverlay(Context context, int screenWidth, int screenHeight, ControlsListener listener) {
        this.context = context;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        contentRoot = new FrameLayout(context);
        contentRoot.setClipChildren(false);
        contentRoot.setClipToPadding(false);

        controls = new LinearLayout(context);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(dp(10), dp(6), dp(6), dp(6));
        controls.setBackground(roundRect(Color.argb(225, 24, 26, 31), dp(18)));

        modeText = controlText("AUTO");
        TextView pause = controlText("⏸");
        TextView close = controlText("✕");

        pause.setPadding(dp(12), dp(7), dp(12), dp(7));
        close.setPadding(dp(12), dp(7), dp(12), dp(7));

        controls.addView(modeText);
        controls.addView(pause);
        controls.addView(close);

        pause.setOnClickListener(v -> listener.onPauseToggle());
        close.setOnClickListener(v -> listener.onStop());
    }

    public void show() {
        if (added) return;

        WindowManager.LayoutParams contentParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        contentParams.gravity = Gravity.TOP | Gravity.START;

        WindowManager.LayoutParams controlParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        controlParams.gravity = Gravity.TOP | Gravity.END;
        controlParams.x = dp(12);
        controlParams.y = dp(72);

        windowManager.addView(contentRoot, contentParams);
        windowManager.addView(controls, controlParams);
        added = true;
    }

    public void setMode(String text) {
        modeText.setText(text);
    }

    public void setContentVisible(boolean visible) {
        contentRoot.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
    }

    public void clearTranslations() {
        contentRoot.removeAllViews();
    }

    public void render(List<TranslationBox> boxes, int bitmapWidth, int bitmapHeight) {
        contentRoot.removeAllViews();
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return;

        float sx = screenWidth / (float) bitmapWidth;
        float sy = screenHeight / (float) bitmapHeight;

        for (TranslationBox box : boxes) {
            Rect r = box.bounds;
            if (r == null || box.translated == null || box.translated.trim().isEmpty()) continue;

            int left = Math.round(r.left * sx);
            int top = Math.round(r.top * sy);
            int rawWidth = Math.max(dp(38), Math.round(r.width() * sx));
            int rawHeight = Math.max(dp(30), Math.round(r.height() * sy));

            // Le japonais vertical est souvent très étroit : on élargit modérément
            // la zone pour que le français reste lisible sans recouvrir la moitié de la page.
            int width = rawWidth;
            int height = rawHeight;
            if (rawHeight > rawWidth * 1.45f) {
                width = Math.min((int) (screenWidth * 0.42f), Math.max(rawWidth * 2, (int) (rawHeight * 0.62f)));
                left = left - (width - rawWidth) / 2;
            }

            int padding = dp(5);
            left = clamp(left - padding, 0, Math.max(0, screenWidth - width));
            top = clamp(top - padding, 0, Math.max(0, screenHeight - height));
            width = Math.min(screenWidth - left, width + padding * 2);
            height = Math.min(screenHeight - top, height + padding * 2);

            TextView tv = new TextView(context);
            tv.setText(box.translated);
            tv.setTextColor(Color.rgb(17, 17, 19));
            tv.setGravity(Gravity.CENTER);
            tv.setIncludeFontPadding(false);
            tv.setPadding(dp(4), dp(3), dp(4), dp(3));
            tv.setBackground(roundRect(Color.argb(242, 255, 255, 255), dp(8)));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                tv.setAutoSizeTextTypeUniformWithConfiguration(
                        9, 22, 1, TypedValue.COMPLEX_UNIT_SP
                );
            } else {
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            }

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
            lp.leftMargin = left;
            lp.topMargin = top;
            contentRoot.addView(tv, lp);
        }
    }

    public void remove() {
        if (!added) return;
        try { windowManager.removeView(contentRoot); } catch (Exception ignored) {}
        try { windowManager.removeView(controls); } catch (Exception ignored) {}
        added = false;
    }

    private TextView controlText(String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(8), dp(7), dp(8), dp(7));
        return view;
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
