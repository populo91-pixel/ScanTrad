# ScanTrad Clean 1.0.1

Rebuild complet de ScanTrad. Aucun code de la série 0.x n'est réutilisé.

## Objectif de cette base

- Capture Android via MediaProjection dans un foreground service conforme Android 14+.
- Overlay de traduction séparé du moteur de capture.
- Mode AUTO piloté par stabilité de l'image : pas d'OCR/traduction en boucle pendant que l'écran ne bouge pas.
- Quand un scroll commence : l'ancienne traduction disparaît une seule fois.
- Quand le scroll s'arrête ~420 ms : OCR, détection de langue, traduction FR, puis affichage une seule fois.
- OCR Latin/Japonais/Chinois/Coréen, avec modèles OCR inclus dans l'APK.
- Identification automatique de la langue et traduction vers le français avec ML Kit.
- Cache des traductions et des modèles par langue.
- Overlay dessiné avec StaticLayout : espaces conservés, retour à la ligne normal, taille de texte adaptative.
- Contrôle flottant AUTO / PAUSE / X.

## Important

La qualité linguistique du moteur ML Kit reste celle d'un traducteur local léger. La nouvelle architecture isole le moteur de traduction derrière `TranslationEngine`, pour permettre plus tard un mode "Qualité" (API distante) sans réécrire capture/OCR/overlay.

## Build

GitHub Actions peut compiler ce projet avec Java 17, Gradle 8.13 et Android SDK 36.


## 1.0.1
- Correction compilation Kotlin dans `OcrEngine.quality`: `String.length` à la place de `String.size`.
