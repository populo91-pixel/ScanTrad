# No shrinking in the clean prototype build.
