package com.scantrad.clean

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.scantrad.clean.capture.CaptureService
import com.scantrad.clean.model.ScriptMode

class MainActivity : androidx.activity.ComponentActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var status: TextView
    private lateinit var spinner: Spinner

    private val projectionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            status.text = "ScanTrad actif. Ouvre ton scan et scroll normalement."
        } else {
            status.text = "Capture d’écran refusée."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MediaProjectionManager::class.java)
        buildUi()
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            status.text = if (Settings.canDrawOverlays(this)) {
                "Prêt. AUTO traduit quand le scroll s’arrête."
            } else {
                "Autorise l’affichage par-dessus les autres apps."
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "ScanTrad Clean"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Nouvelle base : aucune traduction pendant le scroll. L’app attend que l’image soit stable, traduit, puis garde le résultat affiché."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(14), 0, dp(20))
        })

        root.addView(TextView(this).apply {
            text = "OCR source"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                ScriptMode.entries.map { it.label }
            )
            val saved = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_SCRIPT, 0)
            setSelection(saved.coerceIn(0, ScriptMode.entries.lastIndex))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_SCRIPT, position).apply()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        }
        root.addView(spinner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val overlayButton = Button(this).apply {
            text = "1. Autoriser l’overlay"
            setOnClickListener { requestOverlayPermission() }
        }
        root.addView(overlayButton, marginParams())

        val startButton = Button(this).apply {
            text = "2. Démarrer AUTO"
            setOnClickListener { startAuto() }
        }
        root.addView(startButton, marginParams())

        val stopButton = Button(this).apply {
            text = "Arrêter"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_STOP
                })
                status.text = "ScanTrad arrêté."
            }
        }
        root.addView(stopButton, marginParams())

        status = TextView(this).apply {
            text = "Prêt."
            textSize = 15f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(22), 0, 0)
        }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    private fun startAuto() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            status.text = "Autorise l’overlay, puis reviens et appuie sur Démarrer AUTO."
            return
        }
        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            status.text = "Overlay déjà autorisé."
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    private fun marginParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply {
        topMargin = dp(12)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val PREFS = "scantrad_clean_prefs"
        const val KEY_SCRIPT = "script_mode"
    }
}
