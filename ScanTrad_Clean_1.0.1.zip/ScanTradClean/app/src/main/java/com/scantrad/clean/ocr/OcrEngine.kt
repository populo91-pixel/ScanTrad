package com.scantrad.clean.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.scantrad.clean.model.OcrRegion
import com.scantrad.clean.model.ScriptKind
import com.scantrad.clean.model.ScriptMode
import com.scantrad.clean.util.awaitResult
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class OcrEngine {
    private val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val japanese = TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
    private val chinese = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private val korean = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())

    suspend fun recognize(bitmap: Bitmap, mode: ScriptMode): List<OcrRegion> = coroutineScope {
        val jobs = when (mode) {
            ScriptMode.AUTO -> listOf(
                async { recognizeWith(bitmap, latin, ScriptKind.LATIN) },
                async { recognizeWith(bitmap, japanese, ScriptKind.JAPANESE) },
                async { recognizeWith(bitmap, chinese, ScriptKind.CHINESE) },
                async { recognizeWith(bitmap, korean, ScriptKind.KOREAN) }
            )
            ScriptMode.LATIN -> listOf(async { recognizeWith(bitmap, latin, ScriptKind.LATIN) })
            ScriptMode.JAPANESE -> listOf(async { recognizeWith(bitmap, japanese, ScriptKind.JAPANESE) })
            ScriptMode.CHINESE -> listOf(async { recognizeWith(bitmap, chinese, ScriptKind.CHINESE) })
            ScriptMode.KOREAN -> listOf(async { recognizeWith(bitmap, korean, ScriptKind.KOREAN) })
        }
        deduplicate(jobs.awaitAll().flatten())
    }

    private suspend fun recognizeWith(bitmap: Bitmap, recognizer: TextRecognizer, script: ScriptKind): List<OcrRegion> {
        val result = recognizer.process(InputImage.fromBitmap(bitmap, 0)).awaitResult()
        return result.textBlocks.mapNotNull { block ->
            val box = block.boundingBox ?: return@mapNotNull null
            val text = normalizeSource(block.text)
            if (text.length < 2 || box.width() < 8 || box.height() < 8) return@mapNotNull null
            OcrRegion(
                text = text,
                box = Rect(box),
                script = script,
                languageHint = block.recognizedLanguage.takeIf { it.isNotBlank() }
            )
        }
    }

    private fun normalizeSource(text: String): String = text
        .lines()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .joinToString(" ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun deduplicate(input: List<OcrRegion>): List<OcrRegion> {
        val sorted = input.sortedByDescending { quality(it) }
        val kept = mutableListOf<OcrRegion>()
        for (candidate in sorted) {
            val duplicateIndex = kept.indexOfFirst { overlapScore(it.box, candidate.box) > 0.58f }
            if (duplicateIndex == -1) {
                kept += candidate
            } else if (quality(candidate) > quality(kept[duplicateIndex])) {
                kept[duplicateIndex] = candidate
            }
        }
        return kept
            .filter { it.box.top > 0 }
            .sortedWith(compareBy<OcrRegion> { it.box.top }.thenBy { it.box.left })
    }

    private fun quality(region: OcrRegion): Double {
        val chars = region.text.filterNot { it.isWhitespace() }
        if (chars.isEmpty()) return 0.0
        val scriptMatches = chars.count { matchesScript(it, region.script) }
        val ratio = scriptMatches.toDouble() / chars.length
        return region.text.length + ratio * 40.0 + minOf(region.box.width(), region.box.height()) * 0.02
    }

    private fun matchesScript(c: Char, script: ScriptKind): Boolean {
        if (c.isDigit() || c.isWhitespace() || c in ".,!?;:'\"-–—()[]{}…«»") return true
        val unicode = Character.UnicodeScript.of(c.code)
        return when (script) {
            ScriptKind.LATIN -> unicode == Character.UnicodeScript.LATIN
            ScriptKind.JAPANESE -> unicode == Character.UnicodeScript.HIRAGANA ||
                unicode == Character.UnicodeScript.KATAKANA || unicode == Character.UnicodeScript.HAN
            ScriptKind.CHINESE -> unicode == Character.UnicodeScript.HAN
            ScriptKind.KOREAN -> unicode == Character.UnicodeScript.HANGUL
        }
    }

    private fun overlapScore(a: Rect, b: Rect): Float {
        val interLeft = maxOf(a.left, b.left)
        val interTop = maxOf(a.top, b.top)
        val interRight = minOf(a.right, b.right)
        val interBottom = minOf(a.bottom, b.bottom)
        if (interRight <= interLeft || interBottom <= interTop) return 0f
        val intersection = (interRight - interLeft).toLong() * (interBottom - interTop)
        val areaA = a.width().toLong() * a.height()
        val areaB = b.width().toLong() * b.height()
        val union = areaA + areaB - intersection
        return (intersection.toDouble() / union.coerceAtLeast(1)).toFloat()
    }

    fun close() {
        latin.close()
        japanese.close()
        chinese.close()
        korean.close()
    }
}
