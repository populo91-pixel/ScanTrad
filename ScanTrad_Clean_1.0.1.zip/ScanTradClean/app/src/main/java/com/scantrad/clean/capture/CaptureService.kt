package com.scantrad.clean.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.scantrad.clean.MainActivity
import com.scantrad.clean.model.ScriptMode
import com.scantrad.clean.ocr.OcrEngine
import com.scantrad.clean.overlay.ControlOverlay
import com.scantrad.clean.overlay.TranslationOverlayController
import com.scantrad.clean.translate.TranslationEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val processing = AtomicBoolean(false)
    private val stopping = AtomicBoolean(false)
    private val stabilizer = FrameStabilizer()
    private val ocr = OcrEngine()
    private val translator = TranslationEngine()

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var translationOverlay: TranslationOverlayController? = null
    private var controlOverlay: ControlOverlay? = null
    private var paused = false
    @Volatile private var contentGeneration = 0L

    private var captureWidth = 0
    private var captureHeight = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PAUSE -> {
                setPaused(!paused)
                return START_STICKY
            }
            ACTION_START -> startProjection(intent)
        }
        return START_STICKY
    }

    private fun startProjection(intent: Intent) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return
        }

        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )

        if (mediaProjection != null) return

        val wm = getSystemService(WindowManager::class.java)
        val bounds = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds else {
            @Suppress("DEPRECATION")
            android.graphics.Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        }
        captureWidth = bounds.width()
        captureHeight = bounds.height()
        val densityDpi = resources.displayMetrics.densityDpi

        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopEverything()
            }
        }, Handler(mainLooper))

        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 3)
        captureThread = HandlerThread("ScanTradCapture").also { it.start() }
        val captureHandler = Handler(captureThread!!.looper)
        imageReader!!.setOnImageAvailableListener({ reader -> handleImage(reader) }, captureHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScanTradClean",
            captureWidth,
            captureHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        )

        translationOverlay = TranslationOverlayController(this).also { it.attach(captureWidth, captureHeight) }
        controlOverlay = ControlOverlay(
            this,
            onPauseToggle = { setPaused(it) },
            onStop = { stopEverything() }
        ).also { it.attach() }

        paused = false
        contentGeneration++
        stabilizer.forceReprocess()
    }

    private fun handleImage(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        try {
            if (paused) return
            val plane = image.planes.firstOrNull() ?: return
            val fingerprint = makeFingerprint(
                plane.buffer,
                plane.rowStride,
                plane.pixelStride,
                image.width,
                image.height
            )

            when (stabilizer.onFrame(fingerprint)) {
                FrameStabilizer.Event.MOTION_STARTED -> {
                    contentGeneration++
                    translationOverlay?.clear()
                    stabilizer.onVisualOverlayChanged()
                }
                FrameStabilizer.Event.STABLE_NEW_CONTENT -> {
                    if (processing.compareAndSet(false, true)) {
                        val bitmap = imageToBitmap(image)
                        val generation = contentGeneration
                        processStableFrame(bitmap, fingerprint, generation)
                    }
                }
                FrameStabilizer.Event.NONE -> Unit
            }
        } finally {
            image.close()
        }
    }

    private fun processStableFrame(bitmap: Bitmap, fingerprint: IntArray, generation: Long) {
        scope.launch {
            try {
                val modeIndex = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getInt(MainActivity.KEY_SCRIPT, 0)
                val mode = ScriptMode.entries.getOrElse(modeIndex) { ScriptMode.AUTO }
                val regions = ocr.recognize(bitmap, mode)
                    .filterNot { isControlArea(it.box) }
                val translations = translator.translateAll(regions)

                if (generation == contentGeneration && !paused) {
                    stabilizer.markProcessed(fingerprint)
                    withContext(Dispatchers.Main) {
                        translationOverlay?.show(translations)
                        // The overlay appearing changes captured pixels. Reset only the visual baseline,
                        // not the underlying-content history.
                        stabilizer.onVisualOverlayChanged()
                    }
                }
            } catch (_: Throwable) {
                // Keep the service alive; a transient OCR/model failure can recover on the next page.
            } finally {
                bitmap.recycle()
                processing.set(false)
            }
        }
    }

    private fun isControlArea(box: android.graphics.Rect): Boolean {
        val rightZone = captureWidth - dp(150)
        return box.right > rightZone && box.top < dp(190)
    }

    private fun setPaused(value: Boolean) {
        paused = value
        contentGeneration++
        if (value) {
            translationOverlay?.clear()
            stabilizer.onVisualOverlayChanged()
        } else {
            stabilizer.forceReprocess()
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        if (paddedWidth == image.width) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun makeFingerprint(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        width: Int,
        height: Int
    ): IntArray {
        val cols = 28
        val rows = 48
        val out = IntArray(cols * rows)
        val cap = buffer.capacity()
        var n = 0
        for (gy in 0 until rows) {
            val y = ((gy + 0.5f) * height / rows).toInt().coerceIn(0, height - 1)
            for (gx in 0 until cols) {
                val x = ((gx + 0.5f) * width / cols).toInt().coerceIn(0, width - 1)
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 < cap) {
                    val r = buffer.get(offset).toInt() and 0xFF
                    val g = buffer.get(offset + 1).toInt() and 0xFF
                    val b = buffer.get(offset + 2).toInt() and 0xFF
                    out[n++] = (r * 30 + g * 59 + b * 11) / 100
                } else {
                    out[n++] = 0
                }
            }
        }
        return out
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val pauseIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, CaptureService::class.java).apply { action = ACTION_TOGGLE_PAUSE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, CaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("ScanTrad Clean")
            .setContentText(if (paused) "En pause" else "AUTO actif — traduction après le scroll")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, if (paused) "Reprendre" else "Pause", pauseIntent)
            .addAction(0, "Arrêter", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "ScanTrad", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun cleanupProjectionOnly() {
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.close() }
        runCatching { mediaProjection?.stop() }
        runCatching { captureThread?.quitSafely() }
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        captureThread = null
    }

    private fun stopEverything() {
        if (!stopping.compareAndSet(false, true)) return
        contentGeneration++
        translationOverlay?.detach()
        controlOverlay?.detach()
        translationOverlay = null
        controlOverlay = null
        cleanupProjectionOnly()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        contentGeneration++
        translationOverlay?.detach()
        controlOverlay?.detach()
        cleanupProjectionOnly()
        ocr.close()
        translator.close()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val ACTION_START = "com.scantrad.clean.START"
        const val ACTION_STOP = "com.scantrad.clean.STOP"
        const val ACTION_TOGGLE_PAUSE = "com.scantrad.clean.TOGGLE_PAUSE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "scantrad_clean"
        private const val NOTIFICATION_ID = 4101
    }
}
