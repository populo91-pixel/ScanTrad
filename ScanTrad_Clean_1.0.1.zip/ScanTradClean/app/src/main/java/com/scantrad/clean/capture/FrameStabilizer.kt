package com.scantrad.clean.capture

class FrameStabilizer {
    enum class Event { NONE, MOTION_STARTED, STABLE_NEW_CONTENT }

    private var baseline: IntArray? = null
    private var lastUnderlyingProcessed: IntArray? = null
    private var moving = true
    private var lastMotionAt = System.currentTimeMillis()
    private var ignoreFrames = 0
    private var firstSeenAt = System.currentTimeMillis()

    fun onVisualOverlayChanged() {
        ignoreFrames = 2
        baseline = null
    }


    fun forceReprocess() {
        lastUnderlyingProcessed = null
        moving = true
        lastMotionAt = System.currentTimeMillis()
        firstSeenAt = System.currentTimeMillis()
        baseline = null
    }

    fun markProcessed(underlyingFingerprint: IntArray) {
        lastUnderlyingProcessed = underlyingFingerprint.copyOf()
    }

    fun onFrame(fingerprint: IntArray, now: Long = System.currentTimeMillis()): Event {
        if (ignoreFrames > 0) {
            ignoreFrames--
            baseline = fingerprint.copyOf()
            return Event.NONE
        }

        val previous = baseline
        baseline = fingerprint.copyOf()
        if (previous == null) {
            if (now - firstSeenAt > INITIAL_STABLE_MS) {
                moving = false
                return if (isNewEnough(fingerprint)) Event.STABLE_NEW_CONTENT else Event.NONE
            }
            return Event.NONE
        }

        val changed = changedRatio(previous, fingerprint)
        if (changed >= MOTION_RATIO) {
            val wasMoving = moving
            moving = true
            lastMotionAt = now
            return if (!wasMoving) Event.MOTION_STARTED else Event.NONE
        }

        if (moving && now - lastMotionAt >= STABLE_MS) {
            moving = false
            return if (isNewEnough(fingerprint)) Event.STABLE_NEW_CONTENT else Event.NONE
        }

        return Event.NONE
    }

    private fun isNewEnough(current: IntArray): Boolean {
        val old = lastUnderlyingProcessed ?: return true
        return changedRatio(old, current) >= NEW_CONTENT_RATIO
    }

    private fun changedRatio(a: IntArray, b: IntArray): Float {
        val count = minOf(a.size, b.size)
        if (count == 0) return 1f
        var changed = 0
        for (i in 0 until count) {
            if (kotlin.math.abs(a[i] - b[i]) >= POINT_DELTA) changed++
        }
        return changed.toFloat() / count
    }

    companion object {
        private const val POINT_DELTA = 20
        private const val MOTION_RATIO = 0.10f
        private const val NEW_CONTENT_RATIO = 0.07f
        private const val STABLE_MS = 420L
        private const val INITIAL_STABLE_MS = 550L
    }
}
