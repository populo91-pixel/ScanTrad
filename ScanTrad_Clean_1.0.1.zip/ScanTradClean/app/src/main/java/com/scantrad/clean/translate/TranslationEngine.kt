package com.scantrad.clean.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.scantrad.clean.model.OcrRegion
import com.scantrad.clean.model.ScriptKind
import com.scantrad.clean.model.TranslationRegion
import com.scantrad.clean.util.awaitResult
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.util.concurrent.ConcurrentHashMap

class TranslationEngine {
    private val languageIdentifier = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder()
            .setConfidenceThreshold(0.35f)
            .build()
    )
    private val translators = ConcurrentHashMap<String, Translator>()
    private val modelReady = ConcurrentHashMap<String, Boolean>()
    private val textCache = ConcurrentHashMap<String, String>()

    suspend fun translateAll(regions: List<OcrRegion>): List<TranslationRegion> = coroutineScope {
        regions.map { region -> async { translateOne(region) } }
            .awaitAll()
            .filterNotNull()
    }

    private suspend fun translateOne(region: OcrRegion): TranslationRegion? {
        val source = detectLanguage(region) ?: return null
        if (source == TranslateLanguage.FRENCH || source == "fr") return null

        val normalizedSource = TranslateLanguage.fromLanguageTag(source) ?: return null
        val cacheKey = "$normalizedSource|${region.text}"
        textCache[cacheKey]?.let { cached ->
            return TranslationRegion(region.text, cached, region.box, normalizedSource)
        }

        val translator = translators.getOrPut(normalizedSource) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(normalizedSource)
                    .setTargetLanguage(TranslateLanguage.FRENCH)
                    .build()
            )
        }

        if (modelReady[normalizedSource] != true) {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).awaitResult()
            modelReady[normalizedSource] = true
        }

        val translated = translator.translate(region.text).awaitResult()
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex(" *\\n *"), "\n")
            .trim()

        if (translated.isBlank()) return null
        textCache[cacheKey] = translated
        return TranslationRegion(region.text, translated, region.box, normalizedSource)
    }

    private suspend fun detectLanguage(region: OcrRegion): String? {
        val hinted = region.languageHint
            ?.substringBefore('-')
            ?.lowercase()
            ?.takeIf { it != "und" && TranslateLanguage.fromLanguageTag(it) != null }
        if (hinted != null) return hinted

        val identified = languageIdentifier.identifyLanguage(region.text).awaitResult()
            .substringBefore('-')
            .lowercase()
        if (identified != "und" && TranslateLanguage.fromLanguageTag(identified) != null) {
            return identified
        }

        return when (region.script) {
            ScriptKind.JAPANESE -> TranslateLanguage.JAPANESE
            ScriptKind.CHINESE -> TranslateLanguage.CHINESE
            ScriptKind.KOREAN -> TranslateLanguage.KOREAN
            ScriptKind.LATIN -> null
        }
    }

    fun close() {
        languageIdentifier.close()
        translators.values.forEach { it.close() }
        translators.clear()
    }
}
