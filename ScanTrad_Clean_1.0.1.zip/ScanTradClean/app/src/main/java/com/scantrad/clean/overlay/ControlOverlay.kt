package com.scantrad.clean.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout

class ControlOverlay(
    private val context: Context,
    private val onPauseToggle: (Boolean) -> Unit,
    private val onStop: () -> Unit
) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private var attached = false
    private var paused = false
    private lateinit var autoButton: Button
    private lateinit var root: LinearLayout

    fun attach() {
        if (attached) return
        root = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(3), dp(4), dp(3))
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 25, 25, 25))
                cornerRadius = dp(18).toFloat()
            }
        }
        autoButton = smallButton("AUTO").apply {
            setOnClickListener {
                paused = !paused
                text = if (paused) "PAUSE" else "AUTO"
                onPauseToggle(paused)
            }
        }
        val closeButton = smallButton("×").apply { setOnClickListener { onStop() } }
        root.addView(autoButton, LinearLayout.LayoutParams(dp(72), dp(42)))
        root.addView(closeButton, LinearLayout.LayoutParams(dp(44), dp(42)))

        val params = WindowManager.LayoutParams(
            dp(124), dp(48),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(110)
        }
        wm.addView(root, params)
        attached = true
    }

    fun detach() {
        if (attached) {
            runCatching { wm.removeView(root) }
            attached = false
        }
    }

    private fun smallButton(label: String) = Button(context).apply {
        text = label
        textSize = 11f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.TRANSPARENT)
        minWidth = 0
        minHeight = 0
        setPadding(2, 0, 2, 0)
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
