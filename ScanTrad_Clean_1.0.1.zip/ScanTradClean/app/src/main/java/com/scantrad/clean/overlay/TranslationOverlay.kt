package com.scantrad.clean.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.scantrad.clean.model.TranslationRegion
import kotlin.math.max
import kotlin.math.min

class TranslationOverlayController(private val context: Context) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private val view = TranslationOverlayView(context)
    private var attached = false

    fun attach(captureWidth: Int, captureHeight: Int) {
        view.captureWidth = captureWidth
        view.captureHeight = captureHeight
        if (attached) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        wm.addView(view, params)
        attached = true
    }

    fun show(regions: List<TranslationRegion>) {
        view.regions = regions
        view.invalidate()
    }

    fun clear() {
        if (view.regions.isNotEmpty()) {
            view.regions = emptyList()
            view.invalidate()
        }
    }

    fun detach() {
        if (attached) {
            runCatching { wm.removeView(view) }
            attached = false
        }
    }
}

private class TranslationOverlayView(context: Context) : View(context) {
    var regions: List<TranslationRegion> = emptyList()
    var captureWidth: Int = 1
    var captureHeight: Int = 1

    private val density = resources.displayMetrics.density
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(245, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(55, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeWidth = max(1f, density)
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        typeface = Typeface.create("sans", Typeface.NORMAL)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0 || captureWidth <= 0 || captureHeight <= 0) return
        val sx = width.toFloat() / captureWidth
        val sy = height.toFloat() / captureHeight
        regions.forEach { region -> drawRegion(canvas, region, sx, sy) }
    }

    private fun drawRegion(canvas: Canvas, region: TranslationRegion, sx: Float, sy: Float) {
        val original = region.box
        val left = original.left * sx
        val top = original.top * sy
        val right = original.right * sx
        val bottom = original.bottom * sy
        val originalWidth = max(dp(72f), right - left)
        val originalHeight = max(dp(30f), bottom - top)

        // French usually needs more horizontal room than manga text.
        val targetWidth = min(width - dp(16f), max(originalWidth + dp(16f), originalWidth * 1.35f))
        val maxTextHeight = max(originalHeight * 2.5f, dp(64f))
        val padding = dp(8f)
        val layoutWidth = max(dp(48f), targetWidth - padding * 2f).toInt()

        var textSize = min(dp(19f), max(dp(13f), originalHeight * 0.52f))
        var layout = makeLayout(region.translatedText, layoutWidth, textSize)
        while (layout.height > maxTextHeight && textSize > dp(11f)) {
            textSize -= dp(1f)
            layout = makeLayout(region.translatedText, layoutWidth, textSize)
        }

        val bubbleHeight = layout.height + padding * 2f
        var bubbleLeft = (left + right) / 2f - targetWidth / 2f
        var bubbleTop = (top + bottom) / 2f - bubbleHeight / 2f
        bubbleLeft = bubbleLeft.coerceIn(dp(4f), width - targetWidth - dp(4f))
        bubbleTop = bubbleTop.coerceIn(dp(4f), height - bubbleHeight - dp(4f))
        val bubble = RectF(bubbleLeft, bubbleTop, bubbleLeft + targetWidth, bubbleTop + bubbleHeight)

        canvas.drawRoundRect(bubble, dp(10f), dp(10f), backgroundPaint)
        canvas.drawRoundRect(bubble, dp(10f), dp(10f), borderPaint)
        canvas.save()
        canvas.translate(bubble.left + padding, bubble.top + padding)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun makeLayout(text: String, width: Int, sizePx: Float): StaticLayout {
        textPaint.textSize = sizePx
        return StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.03f)
            .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
            .build()
    }

    private fun dp(value: Float): Float = value * density
}
