package com.scantrad.clean.model

import android.graphics.Rect

enum class ScriptMode(val label: String) {
    AUTO("Auto (Latin + Japonais + Chinois + Coréen)"),
    LATIN("Latin"),
    JAPANESE("Japonais"),
    CHINESE("Chinois"),
    KOREAN("Coréen")
}

enum class ScriptKind { LATIN, JAPANESE, CHINESE, KOREAN }

data class OcrRegion(
    val text: String,
    val box: Rect,
    val script: ScriptKind,
    val languageHint: String? = null
)

data class TranslationRegion(
    val originalText: String,
    val translatedText: String,
    val box: Rect,
    val sourceLanguage: String
)
